# คลังไอทีมือสอง

เว็บร้านขายอุปกรณ์ไอทีมือสอง (เมาส์ · คีย์บอร์ด · หูฟัง · เกมคอนโซล) ตรวจสภาพทุกชิ้น รับประกัน 30 วัน
เป็นเว็บ static (HTML / CSS / JavaScript ล้วน) ขึ้น **GitHub Pages** ได้ทันที ไม่ต้องติดตั้งหรือ build อะไร

> ระบบล็อกอิน การชำระเงิน และแชท เป็น **เดโมจำลอง** ไม่ได้เชื่อมต่อบริการจริง
> ข้อมูลตะกร้า/คำสั่งซื้อ/รีวิวเก็บไว้ในเบราว์เซอร์ของผู้ใช้ (localStorage)

## โครงสร้างไฟล์

```
├── index.html        หน้าแรก (แบนเนอร์, สินค้ามาใหม่, ดีลพิเศษ, หมวดหมู่)
├── products.html     สินค้าทั้งหมด + ตัวกรอง (?cat=console  ?q=คำค้น)
├── product.html      รายละเอียดสินค้า + รีวิว (?id=17)
├── cart.html         ตะกร้า + ชำระเงิน (PromptPay / TrueMoney / แอปธนาคาร / บัตร)
├── account.html      บัญชี คำสั่งซื้อ ใบรับประกัน 30 วัน (?warranty=เลขออเดอร์)
├── assets/
│   ├── style.css     สไตล์ของทุกหน้า
│   ├── products.js   ข้อมูลสินค้าทั้งหมด  ← เพิ่ม/แก้สินค้าที่นี่
│   ├── shell.js      เฮดเดอร์ เมนู ล็อกอิน แชท ฯลฯ ที่ใช้ร่วมกันทุกหน้า  ← แก้เมนูที่นี่ที่เดียว
│   └── app.js        ตรรกะของเว็บ
└── images/
    ├── hero-*.jpg    ภาพแบนเนอร์หน้าแรก
    └── products/     รูปสินค้า p{id}.jpg
```

## ขึ้นเว็บด้วย GitHub Pages

1. สร้าง repository ใหม่บน GitHub (เช่นชื่อ `khlang-it`)
2. อัปโหลดไฟล์ **ทั้งหมดในโฟลเดอร์นี้** (ลากวางทั้งโฟลเดอร์ `assets`, `images` และไฟล์ `.html` ลงหน้า *Add file → Upload files*)
   หรือใช้คำสั่ง:
   ```bash
   git init
   git add .
   git commit -m "first commit"
   git branch -M main
   git remote add origin https://github.com/<ชื่อผู้ใช้>/khlang-it.git
   git push -u origin main
   ```
3. ไปที่ **Settings → Pages** เลือก *Source: Deploy from a branch* → Branch: `main` / `(root)` → Save
4. รอ 1–2 นาที เว็บจะอยู่ที่ `https://<ชื่อผู้ใช้>.github.io/khlang-it/`

## ทดลองในเครื่องก่อนอัปโหลด

```bash
python3 -m http.server 8000
# เปิด http://localhost:8000
```
(เปิดไฟล์ `index.html` ด้วยการดับเบิลคลิกก็ใช้ได้ แต่แนะนำให้รันผ่านเซิร์ฟเวอร์แบบข้างบน)

## วิธีแก้ไขที่ใช้บ่อย

| ต้องการ | แก้ที่ไฟล์ |
|---|---|
| เพิ่ม/ลบ/แก้ราคาสินค้า | `assets/products.js` (ใส่รูปไว้ใน `images/products/` แล้วอ้างชื่อไฟล์ใน `img`) |
| แก้เมนู เฮดเดอร์ เบอร์โทรบนสุด | `assets/shell.js` |
| แก้เนื้อหาหน้าแรก / แบนเนอร์ | `index.html` และ `images/hero-*.jpg` |
| เพิ่มหมวดหมู่ใหม่ | `catLabel` และ `icons` ใน `assets/app.js` + checkbox ใน `products.html` + ลิงก์ใน `assets/shell.js` |
| เปลี่ยนสี | ตัวแปร `--rust`, `--paper`, `--ink` ต้นไฟล์ `assets/style.css` |
