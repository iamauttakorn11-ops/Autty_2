// คลังไอทีมือสอง — ตรรกะหลักของเว็บ (ใช้ร่วมกันทุกหน้า)
// หน้าที่เปิดอยู่ดูได้จาก <body data-page="..."> : home | plp | pdp | cart | account

const PAGE = document.body.dataset.page;
const QS = new URLSearchParams(location.search);
const __inFrame = QS.get('embed') === '1';   // โหมดกรอบมือถือ (โหลดหน้าเดียวกันใน iframe)

const $ = id => document.getElementById(id);
// ผูก event แบบปลอดภัย: ถ้าหน้านี้ไม่มี element นั้นก็ข้ามไปเฉย ๆ
function on(id, evt, fn){ const el = document.getElementById(id); if(el) el.addEventListener(evt, fn); }

// เก็บข้อมูลลูกค้าไว้ในเบราว์เซอร์ (ตะกร้า คำสั่งซื้อ รีวิว) เพื่อให้ข้ามหน้าได้
const store = {
  get(k, d){ try{ const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} },
};

const icons = {
  mouse:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="2" width="10" height="18" rx="5"/><line x1="12" y1="2" x2="12" y2="9"/></svg>`,
  keyboard:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2" y="6" width="20" height="12" rx="2"/><line x1="6" y1="10" x2="6" y2="10.01"/><line x1="10" y1="10" x2="10" y2="10.01"/><line x1="14" y1="10" x2="14" y2="10.01"/><line x1="18" y1="10" x2="18" y2="10.01"/><line x1="8" y1="14" x2="16" y2="14"/></svg>`,
  headphone:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 14v-2a9 9 0 0 1 18 0v2"/><rect x="1" y="14" width="6" height="8" rx="2"/><rect x="17" y="14" width="6" height="8" rx="2"/></svg>`,
  console:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2" y="7" width="20" height="11" rx="5"/><line x1="7" y1="12.5" x2="7" y2="12.5"/><line x1="4.5" y1="12.5" x2="9.5" y2="12.5"/><line x1="7" y1="10" x2="7" y2="15"/><circle cx="15.5" cy="11" r="1"/><circle cx="18" cy="13.5" r="1"/></svg>`,
  back:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>`,
  fwd:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>`,
};
document.querySelectorAll('[data-icon]').forEach(el=>{ el.innerHTML = icons[el.dataset.icon]; });
function thumb(p){ return p.img ? `<img src="${p.img}" alt="${p.name}" loading="lazy" style="width:100%;height:100%;object-fit:contain;">` : icons[p.cat]; }

const heroImgs = {mouse:'images/hero-mouse.jpg', keyboard:'images/hero-keyboard.jpg', headphone:'images/hero-headphone.jpg'};
document.querySelectorAll('.hero-slide[data-bgcat]').forEach(el=>{
  const img = heroImgs[el.dataset.bgcat];
  if(img){ el.style.backgroundImage = `url('${img}')`; const art = el.querySelector('.hero-art'); if(art) art.style.display='none'; }
});

const catLabel = {mouse:'เมาส์',keyboard:'คีย์บอร์ด',headphone:'หูฟัง',console:'เกมคอนโซล'};

let cart = store.get('citm_cart', []);          // [{id, qty}]
let lastCat = store.get('citm_lastcat', null);  // หมวดที่ดูล่าสุด (ใช้ปรับแบนเนอร์หน้าแรก)
let currentProduct = products[0];

// บันทึกสถานะทั้งหมดลงเบราว์เซอร์ (เรียกก่อนเปลี่ยนหน้า และตอนปิดหน้า)
function persist(){
  store.set('citm_cart', cart);
  store.set('citm_lastcat', lastCat);
  if(typeof userReviews !== 'undefined') store.set('citm_reviews', userReviews);
  if(typeof pastOrders !== 'undefined') store.set('citm_orders', pastOrders);
}
window.addEventListener('pagehide', persist);

function fmt(n){ return '฿' + n.toLocaleString(); }
function pd(id){ return products.find(p=>p.id===id); }

/* ---------- Navigation (แต่ละหน้าเป็นไฟล์ HTML แยกกัน) ---------- */
const PAGES = {home:'index.html', plp:'products.html', pdp:'product.html', cart:'cart.html', account:'account.html'};
function pageUrl(name, params){
  const q = new URLSearchParams(params || {});
  if(__inFrame) q.set('embed', '1');
  const s = q.toString();
  return PAGES[name] + (s ? '?' + s : '');
}
function navigateTo(url){ location.href = url; }
function showView(name, params){
  if(name === 'pdp' && !(params && params.id)) params = Object.assign({}, params, {id: store.get('citm_lastpid', 1)});
  if(name === PAGE && !params){ window.scrollTo(0, 0); return; }
  persist();
  navigateTo(pageUrl(name, params));
}
document.querySelectorAll('[data-nav]').forEach(el=>{
  el.addEventListener('click', ()=>showView(el.dataset.nav));
});

/* ---------- Home ---------- */
function renderHome(){
  const cat = lastCat;
  document.getElementById('bannerTag').textContent = cat ? 'ปรับตามที่คุณเพิ่งดู' : 'แนะนำสำหรับคุณ';
  document.getElementById('bannerTitle').textContent = cat
    ? `กำลังมองหา${catLabel[cat]}อยู่ใช่ไหม? เรามีของสภาพดีให้เลือกอีกเพียบ`
    : 'ของไอทีมือสองที่ผ่านการตรวจจริง คุ้มกว่าเดิม';
  document.getElementById('bannerText').textContent = cat
    ? `คัดสินค้าในหมวด${catLabel[cat]}ที่ตรวจสภาพและทดสอบแล้วมาให้ดูก่อนใคร`
    : 'ระบบจะปรับสินค้าแนะนำตามหมวดที่คุณเพิ่งดู เริ่มเลือกชมสินค้าได้เลย';
  document.getElementById('recoLabel').textContent = cat ? `เพราะคุณดู ${catLabel[cat]}` : 'ยอดนิยมตอนนี้';

  const reco = (cat ? products.filter(p=>p.cat===cat) : products.slice(0,3)).slice(0,4);
  document.getElementById('recoScroll').innerHTML = reco.map(p=>miniCard(p)).join('');

  document.getElementById('newScroll').innerHTML = [...products].slice(-6).reverse().map(p=>miniCard(p)).join('');
  document.getElementById('dealScroll').innerHTML = products.slice(0,6).map(p=>{
    const off = Math.round((1 - p.price/p.old)*100);
    return `<div class="mini-card deal-card" data-id="${p.id}"><span class="deal-off">-${off}%</span>${miniCardInner(p)}</div>`;
  }).join('');

  document.getElementById('catScroll').innerHTML = Object.entries(catLabel).map(([c,label])=>`
    <div class="mini-card" data-cat="${c}">
      <div class="icon-box">${icons[c]}</div>
      <h4>${label}</h4>
      <span class="meta-line">${products.filter(p=>p.cat===c).length} รายการ</span>
    </div>`).join('');

  document.querySelectorAll('#recoScroll .mini-card, #catScroll .mini-card, #newScroll .mini-card, #dealScroll .mini-card').forEach(el=>{
    el.addEventListener('click', ()=>{
      if(el.dataset.id){ openPDP(+el.dataset.id); }
      else { showView('plp', {cat: el.dataset.cat}); }
    });
  });
}
function miniCardInner(p){
  return `<div class="icon-box">${thumb(p)}</div><h4>${p.name}</h4><span class="price mono"><s style="font-weight:400;font-size:.7rem;color:var(--ink-soft);margin-right:3px;">${fmt(p.old)}</s>${fmt(p.price)}</span>`;
}
if(PAGE === 'home'){
/* ---------- Hero carousel ---------- */
const heroSlides = document.querySelectorAll('#heroCar .hero-slide');
let heroIdx = 0;
document.getElementById('heroDots').innerHTML = [...heroSlides].map((_,i)=>`<button data-i="${i}" class="${i===0?'on':''}"></button>`).join('');
function heroGo(i){
  heroIdx = (i+heroSlides.length)%heroSlides.length;
  heroSlides.forEach((s,j)=>s.classList.toggle('on', j===heroIdx));
  document.querySelectorAll('#heroDots button').forEach((b,j)=>b.classList.toggle('on', j===heroIdx));
}
document.getElementById('heroDots').addEventListener('click', e=>{
  const b=e.target.closest('button'); if(b) heroGo(+b.dataset.i);
});
setInterval(()=>heroGo(heroIdx+1), 5000);
}

/* ---------- Arrow scroll ---------- */
document.querySelectorAll('[data-scroll]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const id = btn.dataset.scroll==='new' ? 'newScroll' : 'dealScroll';
    document.getElementById(id).scrollBy({left: 220*(+btn.dataset.d), behavior:'smooth'});
  });
});
/* ---------- Deals countdown ---------- */
function tickDeals(){
  const now = new Date();
  const end = new Date(); end.setHours(24,0,0,0);
  let diff = Math.max(0,(end-now)/1000);
  const h = String(Math.floor(diff/3600)).padStart(2,'0');
  const m = String(Math.floor(diff/60)%60).padStart(2,'0');
  const s = String(Math.floor(diff)%60).padStart(2,'0');
  const el = document.getElementById('dealsTimer');
  if(el) el.innerHTML = `<div class="u"><b>${h}</b><span>ชม.</span></div><div class="u"><b>${m}</b><span>นาที</span></div><div class="u"><b>${s}</b><span>วินาที</span></div>`;
}
if(PAGE === 'home'){ tickDeals(); setInterval(tickDeals, 1000); }
function miniCard(p){
  return `<div class="mini-card" data-id="${p.id}">
    <div class="icon-box">${thumb(p)}</div>
    <h4>${p.name}</h4>
    <span class="price mono">${fmt(p.price)}</span>
  </div>`;
}
/* ---------- PLP ---------- */
function activeCats(){
  return ['mouse','keyboard','headphone','console'].filter(c=>document.getElementById('fc-'+c).checked);
}
function activeGrades(){
  return ['A','B'].filter(g=>document.getElementById('fg-'+g).checked);
}
function filteredProducts(){
  const q = document.getElementById('searchInput').value.trim().toLowerCase();
  const maxPrice = +document.getElementById('priceRange').value;
  const cats = activeCats(), grades = activeGrades();
  return products.filter(p=>
    cats.includes(p.cat) && grades.includes(p.grade) && p.price<=maxPrice &&
    (!q || p.name.toLowerCase().includes(q) || p.meta.toLowerCase().includes(q))
  );
}
function renderPLP(withSkeleton){
  document.getElementById('priceVal').textContent = fmt(+document.getElementById('priceRange').value);
  const grid = document.getElementById('plpGrid');
  const skel = document.getElementById('skelGrid');
  const list = filteredProducts();
  document.getElementById('plpCount').textContent = list.length + ' รายการ';

  const draw = ()=>{
    grid.style.display = 'grid'; skel.style.display='none';
    grid.innerHTML = list.map(productCard).join('') || `<p class="empty-note">ไม่พบสินค้าที่ตรงกับตัวกรอง</p>`;
    bindCardEvents(grid);
  };
  if(withSkeleton){
    grid.style.display='none'; skel.style.display='grid';
    skel.innerHTML = Array.from({length:4}).map(()=>'<div class="skel-card"></div>').join('');
    setTimeout(draw, 450);
  } else { draw(); }
}
function productCard(p){
  return `<div class="card" data-id="${p.id}">
    <div class="card-top"><span class="grade ${p.grade}">เกรด ${p.grade}</span><span class="sku mono">${p.sku}</span></div>
    <div class="icon-box">${thumb(p)}</div>
    <h3>${p.name}</h3>
    <p class="meta-line">${p.meta}</p>
    <div class="card-bottom">
      <span class="price"><s>${fmt(p.old)}</s>${fmt(p.price)}</span>
    </div>
    <div class="card-actions"><button class="view-btn">ดูสินค้า</button><button class="add-btn" data-id="${p.id}">ใส่ตะกร้า</button></div>
  </div>`;
}
function bindCardEvents(container){
  container.querySelectorAll('.card').forEach(card=>{
    card.addEventListener('click', e=>{
      if(e.target.closest('.add-btn')) return;
      openPDP(+card.dataset.id);
    });
  });
  container.querySelectorAll('.add-btn').forEach(btn=>{
    btn.addEventListener('click', e=>{
      e.stopPropagation();
      addToCart(+btn.dataset.id);
      btn.textContent='เพิ่มแล้ว ✓'; btn.classList.add('added');
      setTimeout(()=>{btn.textContent='ใส่ตะกร้า';btn.classList.remove('added');},1100);
    });
  });
}

if(PAGE === 'plp'){
  ['fc-mouse','fc-keyboard','fc-headphone','fc-console','fg-A','fg-B'].forEach(id=>{
    on(id, 'change', ()=>renderPLP(true));
  });
  on('priceRange', 'input', ()=>renderPLP(true));
  on('clearFilters', 'click', ()=>{
    ['fc-mouse','fc-keyboard','fc-headphone','fc-console','fg-A','fg-B'].forEach(id=>{ $(id).checked = true; });
    $('priceRange').value = 12000; $('searchInput').value = '';
    renderPLP(true);
  });
}
// ช่องค้นหาที่เฮดเดอร์: หน้าสินค้ากรองทันที / หน้าอื่นกด Enter เพื่อไปหน้าสินค้า
on('searchInput', 'input', ()=>{ if(PAGE === 'plp') renderPLP(true); });
on('searchInput', 'keydown', e=>{
  if(e.key === 'Enter' && PAGE !== 'plp'){ showView('plp', {q: e.target.value.trim()}); }
});

/* ---------- Reviews ---------- */
const baseReviews = [
  {name:'คุณต้น', stars:5, text:'สภาพตรงตามรูป ทดสอบก่อนส่งจริง ใช้มา 2 เดือนไม่มีปัญหา'},
  {name:'คุณฝน', stars:4, text:'มีรอยใช้งานเล็กน้อยตามที่แจ้งเกรดไว้ แต่ฟังก์ชันครบทุกปุ่ม'},
  {name:'คุณเจได', stars:5, text:'ส่งไวมาก แพ็คแน่นหนา ราคาคุ้มกว่าซื้อใหม่เยอะ'},
];
let userReviews = store.get('citm_reviews', {}); // pid -> {stars, text}
const starStr = n => '★'.repeat(n) + '☆'.repeat(5-n);
function renderReviews(pid){
  const mine = userReviews[pid];
  const mineHtml = mine ? `<div class="review mine"><div class="stars">${starStr(mine.stars)}</div><b>คุณ (รีวิวของคุณ)</b><p>${mine.text}</p></div>` : '';
  const baseHtml = baseReviews.map(r=>`<div class="review"><div class="stars">${starStr(r.stars)}</div><b>${r.name}</b><p>${r.text}</p></div>`).join('');
  document.getElementById('reviewsList').innerHTML = mineHtml + baseHtml;
  const btn = document.getElementById('pdpReviewBtn');
  btn.textContent = mine ? '✓ แก้ไขรีวิว' : '⭐ เขียนรีวิว';
  btn.classList.toggle('done', !!mine);
}
let rvPid = null, rvStarVal = 5;
function openReviewModal(pid){
  rvPid = pid;
  const existing = userReviews[pid];
  rvStarVal = existing ? existing.stars : 5;
  document.getElementById('rvTitle').textContent = 'รีวิวสินค้า: ' + pd(pid).name;
  document.getElementById('rvText').value = existing ? existing.text : '';
  paintStars();
  document.getElementById('rvOverlay').style.display = 'flex';
}
function paintStars(){
  document.querySelectorAll('#rvStars button').forEach(b=>b.classList.toggle('on', +b.dataset.v <= rvStarVal));
}
on('rvStars','click', e=>{
  const b = e.target.closest('button'); if(!b) return;
  rvStarVal = +b.dataset.v; paintStars();
});
on('rvCancel','click', ()=>{ document.getElementById('rvOverlay').style.display='none'; });
on('rvSubmit','click', ()=>{
  const text = document.getElementById('rvText').value.trim();
  if(!text){ document.getElementById('rvText').focus(); return; }
  userReviews[rvPid] = {stars: rvStarVal, text};
  document.getElementById('rvOverlay').style.display='none';
  persist();
  if(PAGE === 'account') renderOrders();
  if(PAGE === 'pdp' && currentProduct && currentProduct.id === rvPid) renderReviews(rvPid);
});
on('pdpReviewBtn','click', ()=> openReviewModal(currentProduct.id));

/* ---------- PDP (product.html?id=N) ---------- */
function renderPDP(id){
  currentProduct = products.find(p=>p.id===id) || products[0];
  lastCat = currentProduct.cat;
  store.set('citm_lastpid', currentProduct.id);
  document.title = currentProduct.name + ' — คลังไอทีมือสอง';
  $('pdpIcon').innerHTML = thumb(currentProduct);
  $('pdpGrade').textContent = 'เกรด ' + currentProduct.grade;
  $('pdpGrade').className = 'grade ' + currentProduct.grade;
  $('pdpSku').textContent = currentProduct.sku;
  $('pdpName').textContent = currentProduct.name;
  $('pdpMeta').textContent = currentProduct.meta;
  const priceHtml = `<s>${fmt(currentProduct.old)}</s>${fmt(currentProduct.price)}`;
  $('pdpPrice').innerHTML = priceHtml;
  $('pdpPriceSticky').innerHTML = priceHtml;
  renderReviews(currentProduct.id);
}
function openPDP(id){ showView('pdp', {id}); }
on('arToggle', 'click', ()=>{
  const box = $('pdpIcon');
  box.style.transform = box.style.transform === 'rotateY(180deg)' ? '' : 'rotateY(180deg)';
});
on('pdpAddCart', 'click', ()=>addToCart(currentProduct.id));
['pdpBuyNow','pdpBuyNowSticky'].forEach(id=>{
  on(id, 'click', ()=>{ addToCart(currentProduct.id, true); showView('cart'); });
});

let toastTimer;
function showToast(){
  const t=document.getElementById('toast'); t.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),2800);
}
on('toastCart','click', ()=>{document.getElementById('toast').classList.remove('show');showView('cart');});
/* ---------- Cart ---------- */
function addToCart(id,quiet){
  const line = cart.find(c=>c.id===id);
  if(line) line.qty++; else cart.push({id,qty:1});
  document.getElementById('cartCount').textContent = cart.reduce((s,c)=>s+c.qty,0);
  persist();
  if(!quiet) showToast();
}
function renderCart(){
  const wrap = document.getElementById('cartItemsWrap');
  if(cart.length===0){
    wrap.innerHTML = `<p class="empty-note">ยังไม่มีสินค้าในตะกร้า</p><button class="buy-btn" onclick="showView('plp')">ไปเลือกสินค้า →</button>`;
  } else {
    wrap.innerHTML = cart.map(line=>{
      const p = products.find(p=>p.id===line.id);
      return `<div class="cart-item" data-id="${p.id}">
        <div class="icon-box">${thumb(p)}</div>
        <div class="cart-item-info">
          <h4>${p.name}</h4>
          <span class="meta-line mono">${fmt(p.price)}</span>
          <div class="qty-row">
            <button class="qty-btn" data-act="dec">−</button>
            <span class="mono">${line.qty}</span>
            <button class="qty-btn" data-act="inc">+</button>
            <button class="remove-btn" data-act="rm">ลบ</button>
          </div>
        </div>
      </div>`;
    }).join('');
    wrap.querySelectorAll('.cart-item').forEach(row=>{
      const id = +row.dataset.id;
      row.querySelector('[data-act=inc]').addEventListener('click', ()=>{ changeQty(id,1); });
      row.querySelector('[data-act=dec]').addEventListener('click', ()=>{ changeQty(id,-1); });
      row.querySelector('[data-act=rm]').addEventListener('click', ()=>{ cart = cart.filter(c=>c.id!==id); renderCart(); updateCartCount(); });
    });
  }
  const subtotal = cart.reduce((s,c)=>s+c.qty*products.find(p=>p.id===c.id).price,0);
  const total = subtotal + (cart.length?40:0);
  document.getElementById('sumSubtotal').textContent = fmt(subtotal);
  document.getElementById('sumTotal').textContent = fmt(total);
  document.querySelectorAll('.amt').forEach(el=>el.textContent = fmt(total));
  document.getElementById('qrBox').style.display='none';
}
function changeQty(id,delta){
  const line = cart.find(c=>c.id===id);
  line.qty += delta;
  if(line.qty<=0) cart = cart.filter(c=>c.id!==id);
  renderCart(); updateCartCount();
}
function updateCartCount(){ $('cartCount').textContent = cart.reduce((s,c)=>s+c.qty,0); store.set('citm_cart', cart); }
on('showQrBtn','click', ()=>{
  document.getElementById('qrBox').style.display='block';
});
/* ---------- Payment method switching ---------- */
on('payTabs','click', e=>{
  const b = e.target.closest('.pay-tab'); if(!b) return;
  document.querySelectorAll('.pay-tab').forEach(t=>t.classList.toggle('on', t===b));
  document.querySelectorAll('.pay-panel').forEach(p=>{ p.style.display = (p.dataset.panel===b.dataset.pm) ? 'block' : 'none'; });
});
on('bankGrid','click', e=>{
  const b = e.target.closest('.bank-chip'); if(!b) return;
  document.querySelectorAll('.bank-chip').forEach(x=>x.classList.toggle('on', x===b));
});

/* ---------- Unified "payment confirmed" handler (any method) ---------- */
document.querySelectorAll('.pay-confirm').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    if(!requireAuth()) return;
    if(cart.length){
      const subtotal = cart.reduce((s,c)=>s+c.qty*pd(c.id).price,0);
      const ts = Date.now();
      const dateStr = new Date(ts).toLocaleDateString('th-TH',{day:'numeric',month:'short',year:'numeric'});
      const activeTab = document.querySelector('.pay-tab.on');
      const pmLabel = {promptpay:'PromptPay QR',truemoney:'TrueMoney Wallet',bank:'โอนผ่านแอปธนาคาร',card:'บัตรเครดิต/เดบิต'}[activeTab?activeTab.dataset.pm:'promptpay'];
      const newOrder = {
        no: 'TH'+Math.floor(80000+Math.random()*9999),
        date: dateStr,
        ts: ts,
        items: cart.map(c=>({pid:c.id})),
        total: subtotal+40,
        justPaid: true,
        pm: pmLabel,
      };
      pastOrders.unshift(newOrder);
      cart = [];
      updateCartCount();
      persist();
      showView('account', {warranty: newOrder.no});
    } else {
      showView('account');
    }
  });
});
/* ---------- Orders ---------- */
const defaultOrders = [
  {no:'TH88011',date:'12 ก.ย. 2569',ts:Date.now()-86400000*26,items:[{pid:4}],total:1590},
  {no:'TH87650',date:'2 ก.ย. 2569',ts:Date.now()-86400000*36,items:[{pid:7}],total:4290},
];
const pastOrders = store.get('citm_orders', null) || defaultOrders;
function renderOrders(){
  document.getElementById('ordersWrap').innerHTML = pastOrders.map((o,i)=>`
    <div class="order-card">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <h4 style="margin:0;">#${o.no} · ${o.date} ${o.pm?`<span style="color:var(--ink-soft);font-size:.74rem;font-weight:500;">· ${o.pm}</span>`:''} ${o.justPaid?'<span style="color:var(--sage-deep);font-size:.74rem;font-weight:600;">· ชำระสำเร็จ</span>':''}</h4>
        <span class="mono" style="font-size:.82rem;color:var(--ink-soft);">${fmt(o.total)}</span>
      </div>
      ${o.items.map(it=>{
        const p = pd(it.pid);
        const mine = userReviews[it.pid];
        return `<div class="order-item">
          <span class="meta-line" style="margin:0;">${p.name} · ${fmt(p.price)}</span>
          <div style="display:flex;gap:6px;">
            <button class="rebuy-btn" data-act="rebuy" data-pid="${p.id}">ซื้อซ้ำ</button>
            <button class="review-btn ${mine?'done':''}" data-act="review" data-pid="${p.id}">${mine?'✓ แก้ไขรีวิว':'⭐ เขียนรีวิว'}</button>
          </div>
        </div>`;
      }).join('')}
      <button class="review-btn" data-act="warranty" data-idx="${i}" style="margin-top:4px;">📄 ใบรับประกันสินค้า 30 วัน</button>
    </div>`).join('');
  document.querySelectorAll('[data-act=rebuy]').forEach(btn=>{
    btn.addEventListener('click', ()=>{ addToCart(+btn.dataset.pid,true); showView('cart'); });
  });
  document.querySelectorAll('[data-act=review]').forEach(btn=>{
    btn.addEventListener('click', ()=> openReviewModal(+btn.dataset.pid));
  });
  document.querySelectorAll('[data-act=warranty]').forEach(btn=>{
    btn.addEventListener('click', ()=> openWarranty(pastOrders[+btn.dataset.idx]));
  });
}
/* ---------- Warranty certificate ---------- */
function openWarranty(order){
  const purchaseDate = new Date(order.ts || Date.now());
  const expiryDate = new Date(purchaseDate.getTime() + 30*86400000);
  const fmtDate = d => d.toLocaleDateString('th-TH',{day:'numeric',month:'long',year:'numeric'});
  const isExpired = Date.now() > expiryDate.getTime();
  const rows = order.items.map(it=>{
    const p = pd(it.pid);
    return `<tr><td>${p.name}</td><td class="mono">${p.sku}</td><td>เกรด ${p.grade}</td><td class="mono">${fmt(p.price)}</td></tr>`;
  }).join('');
  const custName = currentUser ? currentUser.name : 'ลูกค้า';
  document.getElementById('warrantyDoc').innerHTML = `
    <span class="wr-badge">${isExpired ? '⏱ การรับประกันสิ้นสุดแล้ว' : '✓ อยู่ในช่วงรับประกัน'}</span>
    <h1>ใบรับประกันสินค้า 30 วัน</h1>
    <p class="wr-sub">Electronic Warranty Certificate · คลังไอทีมือสอง</p>
    <div class="wr-meta">
      <div><b>เลขที่ใบรับประกัน:</b> WR-${order.no}</div>
      <div><b>เลขที่คำสั่งซื้อ:</b> ${order.no}</div>
      <div><b>ชื่อลูกค้า:</b> ${custName}</div>
      <div><b>ช่องทางชำระเงิน:</b> ${order.pm || '-'}</div>
      <div><b>วันที่ซื้อ:</b> ${fmtDate(purchaseDate)}</div>
      <div><b>รับประกันถึงวันที่:</b> ${fmtDate(expiryDate)}</div>
    </div>
    <table>
      <thead><tr><th>รายการสินค้า</th><th>SKU</th><th>เกรดสภาพ</th><th>ราคา</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <h4>ความคุ้มครอง (Covered)</h4>
    <ul>
      <li>ความชำรุดบกพร่องที่เกิดจากการทำงานผิดปกติของอุปกรณ์ภายใต้การใช้งานปกติ</li>
      <li>ปุ่มกด สวิตช์ หรือฟังก์ชันหลักไม่ทำงานตามที่ระบุไว้ตอนซื้อ</li>
      <li>เปลี่ยนสินค้าชิ้นใหม่ หรือซ่อมแซมโดยไม่มีค่าใช้จ่าย ภายในระยะเวลารับประกัน</li>
    </ul>
    <h4>ไม่ครอบคลุม (Not Covered)</h4>
    <ul>
      <li>ความเสียหายจากอุบัติเหตุ ตกหล่น ของเหลวเข้าเครื่อง หรือการใช้งานผิดวิธี</li>
      <li>การแกะ ซ่อม หรือดัดแปลงโดยช่างนอกร้าน</li>
      <li>ความเสียหายจากไฟฟ้าลัดวงจรหรือภัยธรรมชาติ</li>
    </ul>
    <div class="wr-foot">
      <span>ออกเอกสารโดยระบบอัตโนมัติ · ไม่ต้องลงนาม</span>
      <span>คลังไอทีมือสอง · 02 105 4757</span>
    </div>
  `;
  document.getElementById('wrOverlay').classList.add('open');
}
on('wrClose','click', ()=>{ document.getElementById('wrOverlay').classList.remove('open'); });
on('wrPrint','click', ()=> window.print());
/* ---------- Chatbot ---------- */
const chatFab = document.getElementById('chatFab');
const chatPanel = document.getElementById('chatPanel');
chatFab.addEventListener('click', ()=>chatPanel.classList.toggle('open'));
const chatReplies = {
  track: 'พัสดุคำสั่งซื้อล่าสุดของคุณอยู่ในสถานะ "จัดส่งแล้ว" คาดว่าจะถึงภายในวันพรุ่งนี้ค่ะ',
  warranty: 'สินค้าทุกชิ้นรับประกัน 30 วันหลังได้รับสินค้า หากพบปัญหาแจ้งเคลมได้ทันทีค่ะ',
  return: 'สามารถแจ้งขอคืนสินค้าได้ภายใน 7 วัน โดยสภาพต้องตรงตามตอนได้รับค่ะ ต้องการให้เริ่มเรื่องคืนสินค้าไหมคะ',
};
document.querySelectorAll('.chat-quick button').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const body = document.getElementById('chatBody');
    body.insertAdjacentHTML('beforeend', `<div class="chat-msg user">${btn.textContent}</div>`);
    body.insertAdjacentHTML('beforeend', `<div class="chat-msg">${chatReplies[btn.dataset.q]}</div>`);
    body.scrollTop = body.scrollHeight;
  });
});

/* ---------- โหมดกรอบมือถือ: โหลดหน้าเดียวกันใน iframe (?embed=1) ---------- */
(function(){
  const vmBar = $('viewModeBar');
  if(!vmBar) return;
  if(__inFrame){ const bar = $('previewBar'); if(bar) bar.style.display = 'none'; return; }
  const iframe = $('phoneIframe');
  let opened = false;
  function frameUrl(){ const u = new URL(location.href); u.hash = ''; u.searchParams.set('embed', '1'); return u.toString(); }
  function openFrame(){ persist(); iframe.src = frameUrl(); document.body.classList.add('mode-frame'); opened = true; }
  function closeFrame(){
    document.body.classList.remove('mode-frame');
    iframe.src = 'about:blank';
    if(opened) location.reload();   // โหลดใหม่เพื่อดึงตะกร้า/คำสั่งซื้อที่เปลี่ยนในกรอบมือถือ
  }
  vmBar.addEventListener('click', e=>{
    const b = e.target.closest('.vmb-btn'); if(!b) return;
    vmBar.querySelectorAll('.vmb-btn').forEach(x=>x.classList.toggle('on', x===b));
    if(b.dataset.mode === 'frame') openFrame(); else closeFrame();
  });
})();


/* ---------- Nav drawer ---------- */
const drawerOv = $('drawerOv');
function openDrawer(){ drawerOv.classList.add('open'); }
function closeDrawer(){ drawerOv.classList.remove('open'); }
on('menuBtn', 'click', openDrawer);
on('drawerClose', 'click', closeDrawer);
drawerOv.addEventListener('click', e=>{ if(e.target === drawerOv) closeDrawer(); });
document.querySelectorAll('.drawer-link[data-dnav]').forEach(btn=>{
  btn.addEventListener('click', ()=>{ closeDrawer(); showView(btn.dataset.dnav); });
});
document.querySelectorAll('.drawer-link[data-dcat]').forEach(btn=>{
  btn.addEventListener('click', ()=>{ closeDrawer(); showView('plp', {cat: btn.dataset.dcat}); });
});
on('drawerAuthBtn', 'click', ()=>{
  closeDrawer();
  if(currentUser){ currentUser = null; clearStoredUser(); updateUserUI(); }
  showAuthGate();
});

/* ---------- Topbar links (no real navigation; copy-to-clipboard instead) ---------- */
document.querySelectorAll('.topbar-row a').forEach(a=>{
  a.addEventListener('click', e=>{
    e.preventDefault();
    const val = a.dataset.copy;
    if(!val) return;
    try{ navigator.clipboard.writeText(val); }catch(err){}
    const txt = a.querySelector('.tb-txt');
    if(txt){
      const original = txt.textContent;
      txt.textContent = 'คัดลอกแล้ว ✓';
      setTimeout(()=>{ txt.textContent = original; }, 1400);
    }
  });
});
/* ---------- Auth ---------- */
let currentUser = null;
function getStoredUser(){
  try{ const v = localStorage.getItem('citm_auth_user'); return v ? JSON.parse(v) : null; }catch(e){ return null; }
}
function setStoredUser(u){ try{ localStorage.setItem('citm_auth_user', JSON.stringify(u)); }catch(e){} }
function clearStoredUser(){ try{ localStorage.removeItem('citm_auth_user'); sessionStorage.removeItem('citm_guest'); }catch(e){} }

function hideAuthGate(){
  document.getElementById('authGate').style.display = 'none';
  const m = document.getElementById('authContextMsg');
  if(m) m.style.display = 'none';
}
function showAuthGate(){ document.getElementById('authGate').style.display = 'flex'; }
function requireAuth(){
  if(currentUser) return true;
  const m = document.getElementById('authContextMsg');
  if(m) m.style.display = 'block';
  showAuthGate();
  return false;
}

function updateUserUI(){
  const g = document.getElementById('userGreeting');
  const e = document.getElementById('userEmail');
  const av = document.getElementById('userAvatar');
  const dAuth = document.getElementById('drawerAuthLabel');
  if(dAuth) dAuth.textContent = currentUser ? 'ออกจากระบบ (' + currentUser.name + ')' : 'เข้าสู่ระบบ';
  if(!g) return;
  if(currentUser){
    g.textContent = 'สวัสดี, ' + currentUser.name;
    e.textContent = currentUser.email || (currentUser.provider==='google'?'เชื่อมต่อผ่าน Google':currentUser.provider==='facebook'?'เชื่อมต่อผ่าน Facebook':'');
    av.textContent = currentUser.name.charAt(0).toUpperCase();
  } else {
    g.textContent = 'ผู้เยี่ยมชม (ยังไม่ได้เข้าสู่ระบบ)';
    e.textContent = '';
    av.textContent = '?';
  }
}

function loginSuccess(user){
  currentUser = user;
  setStoredUser(user);
  hideAuthGate();
  updateUserUI();
}

on('authTabs','click', e=>{
  const t = e.target.closest('.auth-tab'); if(!t) return;
  document.querySelectorAll('.auth-tab').forEach(x=>x.classList.toggle('on', x===t));
  document.querySelectorAll('.auth-panel').forEach(p=>{ p.style.display = (p.dataset.panel===t.dataset.tab) ? 'block' : 'none'; });
});

on('loginBtn','click', ()=>{
  const email = document.getElementById('loginEmail').value.trim();
  const pass = document.getElementById('loginPass').value;
  if(!email || !pass){ alert('กรุณากรอกอีเมลและรหัสผ่าน'); return; }
  loginSuccess({name: email.split('@')[0], email, provider:'email'});
});
on('signupBtn','click', ()=>{
  const name = document.getElementById('suName').value.trim();
  const email = document.getElementById('suEmail').value.trim();
  const pass = document.getElementById('suPass').value;
  if(!name || !email || pass.length < 6){ alert('กรุณากรอกข้อมูลให้ครบ (รหัสผ่านอย่างน้อย 6 ตัวอักษร)'); return; }
  loginSuccess({name, email, provider:'email'});
});
function socialLogin(provider, btn){
  const label = btn.querySelector('.lbl');
  const original = label.textContent;
  btn.classList.add('loading');
  label.textContent = 'กำลังเชื่อมต่อ...';
  setTimeout(()=>{
    btn.classList.remove('loading');
    label.textContent = original;
    loginSuccess({name: provider==='google' ? 'ผู้ใช้ Google' : 'ผู้ใช้ Facebook', email:'', provider});
  }, 900);
}
on('googleBtn','click', e=>socialLogin('google', e.currentTarget));
on('fbBtn','click', e=>socialLogin('facebook', e.currentTarget));
on('guestBtn','click', ()=>{
  currentUser = null; updateUserUI();
  try{ sessionStorage.setItem('citm_guest', '1'); }catch(e){}
  hideAuthGate();
});
on('logoutBtn','click', ()=>{
  currentUser = null;
  clearStoredUser();
  updateUserUI();
  showAuthGate();
});

(function(){
  const u = getStoredUser();
  if(u) currentUser = u;
  let guest = false;
  try{ guest = !!sessionStorage.getItem('citm_guest'); }catch(e){}
  if(__inFrame || u || guest) hideAuthGate(); else showAuthGate();
  updateUserUI();
})();

/* ---------- Init: เรียกเฉพาะส่วนของหน้าที่เปิดอยู่ ---------- */
updateCartCount();
if(PAGE === 'home'){ renderHome(); }
if(PAGE === 'plp'){
  const qcat = QS.get('cat');
  if(qcat && catLabel[qcat]){
    ['mouse','keyboard','headphone','console'].forEach(c=>{ $('fc-' + c).checked = (c === qcat); });
    lastCat = qcat;
  }
  const qq = QS.get('q');
  if(qq) $('searchInput').value = qq;
  renderPLP();
}
if(PAGE === 'pdp'){ renderPDP(+QS.get('id') || store.get('citm_lastpid', 1)); }
if(PAGE === 'cart'){ renderCart(); }
if(PAGE === 'account'){
  renderOrders();
  const w = QS.get('warranty');
  if(w){
    const order = pastOrders.find(o=>o.no === w);
    if(order) openWarranty(order);
    const u2 = new URL(location.href); u2.searchParams.delete('warranty');
    history.replaceState(null, '', u2.pathname + u2.search);
  }
}

