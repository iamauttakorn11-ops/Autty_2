// ข้อมูลสินค้าทั้งหมดของร้าน — แก้ไข/เพิ่มสินค้าได้ที่ไฟล์นี้
// cat: mouse | keyboard | headphone | console   ·   grade: A | B   ·   img: ที่อยู่ไฟล์รูปในโฟลเดอร์ images/
const products = [
  {
    "id": 1,
    "cat": "mouse",
    "name": "Logitech G502 X PLUS Wireless",
    "meta": "ไร้สาย · RGB LIGHTSYNC · ปุ่มปรับ DPI ได้",
    "grade": "A",
    "sku": "MS-1042",
    "price": 1290,
    "old": 2490,
    "img": "images/products/p1.jpg"
  },
  {
    "id": 2,
    "cat": "mouse",
    "name": "Logitech G502 HERO Wired",
    "meta": "มีสาย · เซนเซอร์ HERO 25K · ปุ่มมาโคร 11 ปุ่ม",
    "grade": "B",
    "sku": "MS-0877",
    "price": 690,
    "old": 1590,
    "img": "images/products/p2.jpg"
  },
  {
    "id": 3,
    "cat": "mouse",
    "name": "Logitech MX Master 3S",
    "meta": "ไร้สาย/บลูทูธ · ปุ่มคลิกเงียบ Silent",
    "grade": "A",
    "sku": "MS-1180",
    "price": 1090,
    "old": 1990,
    "img": "images/products/p3.jpg"
  },
  {
    "id": 10,
    "cat": "mouse",
    "name": "Logitech Lift Vertical Ergonomic",
    "meta": "แนวตั้งลดอาการปวดข้อมือ · บลูทูธ",
    "grade": "A",
    "sku": "MS-1301",
    "price": 890,
    "old": 1590,
    "img": "images/products/p10.jpg"
  },
  {
    "id": 4,
    "cat": "keyboard",
    "name": "Keychron Q1 Pro Knob",
    "meta": "Gasket Mount · ปุ่มหมุนปรับเสียง · คีย์แคปน้ำเงิน-เทา",
    "grade": "A",
    "sku": "KB-2231",
    "price": 2490,
    "old": 4290,
    "img": "images/products/p4.jpg"
  },
  {
    "id": 5,
    "cat": "keyboard",
    "name": "Apple Magic Keyboard (TH)",
    "meta": "ไร้สาย · เค้าโครงภาษาไทย · แบตชาร์จได้",
    "grade": "A",
    "sku": "KB-1904",
    "price": 1490,
    "old": 2590,
    "img": "images/products/p5.jpg"
  },
  {
    "id": 6,
    "cat": "keyboard",
    "name": "60% Mechanical RGB Compact",
    "meta": "มีสาย · RGB Backlit · ขนาดกะทัดรัด",
    "grade": "A",
    "sku": "KB-2450",
    "price": 1290,
    "old": 2290,
    "img": "images/products/p6.jpg"
  },
  {
    "id": 11,
    "cat": "keyboard",
    "name": "Standard Wired Keyboard (Full Size)",
    "meta": "มีสาย · ปุ่มกดครบพร้อม Numpad",
    "grade": "B",
    "sku": "KB-2601",
    "price": 290,
    "old": 590,
    "img": "images/products/p11.jpg"
  },
  {
    "id": 12,
    "cat": "keyboard",
    "name": "MEZZON RGB Wireless Mechanical",
    "meta": "ไร้สาย 2.4G · RGB Backlit · เค้าโครงไทย",
    "grade": "A",
    "sku": "KB-2712",
    "price": 1690,
    "old": 2990,
    "img": "images/products/p12.jpg"
  },
  {
    "id": 7,
    "cat": "headphone",
    "name": "Sony WH-CH720N (Pink)",
    "meta": "ไร้สาย · ตัดเสียงรบกวน · แบตทดสอบ 90%+",
    "grade": "A",
    "sku": "HP-3312",
    "price": 1990,
    "old": 3590,
    "img": "images/products/p7.jpg"
  },
  {
    "id": 8,
    "cat": "headphone",
    "name": "HyperX Cloud Alpha S",
    "meta": "มีสาย · ไมค์ถอดได้ · เบสปรับได้",
    "grade": "A",
    "sku": "HP-2077",
    "price": 1590,
    "old": 2990,
    "img": "images/products/p8.jpg"
  },
  {
    "id": 9,
    "cat": "headphone",
    "name": "Logitech G PRO X Gaming",
    "meta": "มีสาย · ไมค์ถอดได้ · เสียงรอบทิศ",
    "grade": "A",
    "sku": "HP-2984",
    "price": 1890,
    "old": 3490,
    "img": "images/products/p9.jpg"
  },
  {
    "id": 13,
    "cat": "headphone",
    "name": "Marshall Mid ANC",
    "meta": "บลูทูธ · ตัดเสียงรบกวน · เสียงหนึบสไตล์ Marshall",
    "grade": "A",
    "sku": "HP-3401",
    "price": 2290,
    "old": 3990,
    "img": "images/products/p13.jpg"
  },
  {
    "id": 14,
    "cat": "headphone",
    "name": "Gaming Headset RGB Wireless 2.4G",
    "meta": "ไร้สาย 2.4G · RGB · มีดองเกิล USB",
    "grade": "B",
    "sku": "HP-3512",
    "price": 890,
    "old": 1690,
    "img": "images/products/p14.jpg"
  },
  {
    "id": 15,
    "cat": "headphone",
    "name": "Gaming Headset RGB Wired",
    "meta": "มีสาย · RGB · ไมโครโฟนปรับได้",
    "grade": "B",
    "sku": "HP-3623",
    "price": 590,
    "old": 1190,
    "img": "images/products/p15.jpg"
  },
  {
    "id": 16,
    "cat": "console",
    "name": "Sony PlayStation 4 (500GB)",
    "meta": "เครื่อง + จอยแท้ 1 ชิ้น · ทดสอบแผ่น/เกมแล้ว",
    "grade": "A",
    "sku": "CS-4001",
    "price": 5990,
    "old": 8990,
    "img": "images/products/p16.jpg"
  },
  {
    "id": 17,
    "cat": "console",
    "name": "Sony PlayStation 5 (White)",
    "meta": "รุ่นมีช่องใส่แผ่น · จอยแท้ 1 ชิ้น",
    "grade": "A",
    "sku": "CS-5002",
    "price": 11990,
    "old": 16990,
    "img": "images/products/p17.jpg"
  },
  {
    "id": 18,
    "cat": "console",
    "name": "Logitech G29 Driving Force",
    "meta": "พวงมาลัย + คันเร่ง-เบรก 3 แป้น · รองรับ PS/PC",
    "grade": "A",
    "sku": "CS-2910",
    "price": 4990,
    "old": 7990,
    "img": "images/products/p18.jpg"
  },
  {
    "id": 19,
    "cat": "console",
    "name": "Logitech G923 TRUEFORCE",
    "meta": "พวงมาลัย Force Feedback + แป้นเหยียบโลหะ",
    "grade": "A",
    "sku": "CS-2920",
    "price": 6990,
    "old": 10990,
    "img": "images/products/p19.jpg"
  }
];
